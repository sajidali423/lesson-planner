// Array to store lesson plans
const lessonPlans = [];

// Add event listener to the form to save the lesson plan
document.getElementById('lessonPlanForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const grade = document.getElementById('grade').value;
    const subject = document.getElementById('subject').value;
    const month = document.getElementById('month').value;
    const activate = document.getElementById('activate').value;
    const acquire = document.getElementById('acquire').value;
    const apply = document.getElementById('apply').value;
    const assess = document.getElementById('assess').value;

    const lessonPlan = {
        grade,
        subject,
        month,
        activate,
        acquire,
        apply,
        assess
    };

    lessonPlans.push(lessonPlan);
    console.log('Lesson plan saved:', lessonPlan);
    alert('Lesson plan saved successfully!');
});

// Event listener for exporting data as JSON
document.getElementById('exportJsonBtn').addEventListener('click', function() {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(lessonPlans));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "lessonPlans.json");
    document.body.appendChild(downloadAnchorNode); // Required for Firefox
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
});

// Event listener for exporting data as CSV
document.getElementById('exportCsvBtn').addEventListener('click', function() {
    const csvRows = [];

    // Headers
    const headers = ['Grade', 'Subject', 'Month', 'Activating Prior Knowledge', 'Acquiring New Knowledge', 'Applying the Knowledge', 'Assessing the Knowledge'];
    csvRows.push(headers.join(','));

    // Rows
    lessonPlans.forEach(lessonPlan => {
        const values = [
            lessonPlan.grade,
            lessonPlan.subject,
            lessonPlan.month,
            lessonPlan.activate.replace(/(\r\n|\n|\r)/gm, " ").trim(),
            lessonPlan.acquire.replace(/(\r\n|\n|\r)/gm, " ").trim(),
            lessonPlan.apply.replace(/(\r\n|\n|\r)/gm, " ").trim(),
            lessonPlan.assess.replace(/(\r\n|\n|\r)/gm, " ").trim()
        ];
        csvRows.push(values.join(','));
    });

    const csvString = csvRows.join('\n');
    const dataStr = "data:text/csv;charset=utf-8," + encodeURIComponent(csvString);
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "lessonPlans.csv");
    document.body.appendChild(downloadAnchorNode); // Required for Firefox
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
});

// Event listener for exporting data as PDF
document.getElementById('exportPdfBtn').addEventListener('click', function() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    lessonPlans.forEach((lessonPlan, index) => {
        doc.text(`Lesson Plan ${index + 1}`, 10, 10 + (index * 60));
        doc.text(`Grade: ${lessonPlan.grade}`, 10, 20 + (index * 60));
        doc.text(`Subject: ${lessonPlan.subject}`, 10, 30 + (index * 60));
        doc.text(`Month: ${lessonPlan.month}`, 10, 40 + (index * 60));
        doc.text(`Activating Prior Knowledge: ${lessonPlan.activate}`, 10, 50 + (index * 60));
        doc.text(`Acquiring New Knowledge: ${lessonPlan.acquire}`, 10, 60 + (index * 60));
        doc.text(`Applying the Knowledge: ${lessonPlan.apply}`, 10, 70 + (index * 60));
        doc.text(`Assessing the Knowledge: ${lessonPlan.assess}`, 10, 80 + (index * 60));
        if (index < lessonPlans.length - 1) {
            doc.addPage();
        }
    });

    doc.save('lessonPlans.pdf');
});
